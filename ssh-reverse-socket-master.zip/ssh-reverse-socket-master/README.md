# SSHReverseSocket

#### 介绍

* 一键脚本，通过ssh创建反向socket代理，解决服务器没网的问题

* 适用于服务器没网，本机有网，且本机可以ssh到服务器上的情况

#### 原理

* 通过ssh -R命令启动一个反向隧道

* 再在本机启动一个python-socket5服务器

* 在服务器上设置socket代理，则流量会通过ssh反向隧道传入本机的socket服务器，服务器即可上网

#### 使用方法

1. 启动命令：
```
python socket5_proxy.py --ssh_cmd "user@host -p port" --socket5_port 3089
```

1. 等待输入密码

1. 在服务端设置socket代理：
```
export http_proxy="socks5h://127.0.0.1:3089"
export https_proxy="socks5h://127.0.0.1:3089"
```

#### 注意

* 如果服务器不能解析域名，设置代理时要用"socks5**h**://host:port"，而不是"socks5://host:port"
* 如果本地已经有socket代理，则可以使用脚本: socket5_proxy.cmd，启动该脚本前修改下脚本内参数:
  1. LOCAL_SOCKET_PORT: 本地socket代理端口
  1. REMOTE_SOCKET_PORT: 服务器socket端口，随便指定一个未被占用的端口即可
  1. SSH_CMD: 服务器ssh登录命令，如：xxx@xx.xx.xx.xx -p xxx